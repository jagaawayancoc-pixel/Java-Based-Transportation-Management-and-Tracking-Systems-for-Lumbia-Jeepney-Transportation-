package service;

import model.Driver;
import java.util.ArrayList;
import java.util.List;

/** Provides the Passenger dashboard with the latest persisted driver state. */
public class PassengerService {
    public List<Driver> getAvailableDrivers(String route) {
        List<Driver> result = new ArrayList<>();
        for (Driver d : DriverService.getActiveDrivers()) {
            if (d.isDeparting() && route.equalsIgnoreCase(d.getRoute())) {
                result.add(d);
            }
        }
        return result;
    }

    public String getProgress(String route, String stop) {
        return RouteService.getProgress(route, stop);
    }

    public String getPassedStops(String route, String stop) {
        return RouteService.getPassedStops(route, stop);
    }

    public String getNextStop(String route, String stop) {
        return RouteService.getNextStop(route, stop);
    }
}
