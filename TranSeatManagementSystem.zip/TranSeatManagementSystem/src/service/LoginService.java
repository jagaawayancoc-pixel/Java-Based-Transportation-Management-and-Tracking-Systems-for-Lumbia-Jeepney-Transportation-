package service;

import model.Admin;
import model.Driver;
import model.Login;

public class LoginService {
    public boolean isAdmin(Login login) {
        return login != null
                && "Admin".equalsIgnoreCase(login.getUserType())
                && Admin.USERNAME.equals(login.getName())
                && Admin.PASSWORD.equals(login.getpassword());
    }

    public Driver authenticateDriver(Login login) {
        if (login == null || !"Driver".equalsIgnoreCase(login.getUserType())) {
            return null;
        }
        Driver driver = DriverService.findByName(login.getName());
        if (driver != null) {
            return driver;
        }
        return null;
    }

    /*
     * Drivers are created by the administrator. Their unique name is used
     * as their login name, and the same name is used as the initial secret.
     * This avoids a driver self-sign-up screen while keeping the prototype simple.
     */
    public boolean isPassenger(Login login) {
        return login != null
                && "Passenger".equalsIgnoreCase(login.getUserType())
                && login.getName() != null
                && !login.getName().trim().isEmpty();
    }
}
