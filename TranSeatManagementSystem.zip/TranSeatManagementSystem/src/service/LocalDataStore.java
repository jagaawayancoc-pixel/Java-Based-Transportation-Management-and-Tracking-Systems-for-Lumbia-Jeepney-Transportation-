package service;

import model.Driver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * Small dependency-free local data store.
 *
 * This replaces the previous XAMPP/MySQL dependency for the desktop version.
 * The data is stored under the user's home directory so separate Java
 * processes can see the same driver/departure information.
 */
public final class LocalDataStore {
    private static final File DATA_DIR = new File(
            System.getProperty("user.home"), "TranSeatManagementSystem");
    private static final File DATA_FILE = new File(DATA_DIR, "drivers.dat");
    private static final File TEMP_FILE = new File(DATA_DIR, "drivers.tmp");

    private LocalDataStore() { }

    public static synchronized List<Driver> loadDrivers() {
        if (!DATA_FILE.exists()) return new ArrayList<>();

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            Object object = in.readObject();
            if (object instanceof DriverData) {
                return new ArrayList<>(((DriverData) object).drivers);
            }
        } catch (Exception ignored) {
            // A damaged/empty local file should not prevent the application from opening.
        }
        return new ArrayList<>();
    }

    public static synchronized void saveDrivers(List<Driver> drivers) {
        try {
            if (!DATA_DIR.exists() && !DATA_DIR.mkdirs()) return;

            DriverData data = new DriverData(drivers);
            try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(TEMP_FILE))) {
                out.writeObject(data);
                out.flush();
            }

            try {
                Files.move(TEMP_FILE.toPath(), DATA_FILE.toPath(),
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception atomicMoveNotSupported) {
                Files.move(TEMP_FILE.toPath(), DATA_FILE.toPath(),
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ignored) {
            // Keep the running application usable even if local persistence fails.
        }
    }

    private static class DriverData implements Serializable {
        private static final long serialVersionUID = 1L;
        private final List<Driver> drivers;

        DriverData(List<Driver> drivers) {
            this.drivers = new ArrayList<>(drivers);
        }
    }
}
