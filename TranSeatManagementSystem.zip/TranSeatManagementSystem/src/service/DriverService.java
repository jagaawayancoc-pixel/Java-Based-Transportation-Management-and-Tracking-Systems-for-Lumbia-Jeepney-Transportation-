package service;

import model.Driver;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Central business logic for drivers and live departure information. */
public class DriverService {

    private static List<Driver> drivers = new ArrayList<>();

    static {
        reload();
    }

    /** Reload the latest state so separate Driver/Passenger windows/processes can sync. */
    public static synchronized void reload() {
        drivers = LocalDataStore.loadDrivers();
    }

    private static void save() {
        LocalDataStore.saveDrivers(drivers);
    }

    public static synchronized boolean addDriver(String id, String name, String plate) {
        reload();
        if (isBlank(id) || isBlank(name) || isBlank(plate)) return false;
        if (findByIdInternal(id) != null || findByNameInternal(name) != null) return false;
        drivers.add(new Driver(id.trim(), name.trim(), plate.trim()));
        save();
        return true;
    }

    public static synchronized boolean updateDriver(String id, String name, String plate) {
        reload();
        Driver driver = findByIdInternal(id);
        if (driver == null || driver.isArchived() || isBlank(name) || isBlank(plate)) return false;

        Driver sameName = findByNameInternal(name);
        if (sameName != null && sameName != driver) return false;

        driver.setName(name.trim());
        driver.setPlateNumber(plate.trim());
        save();
        return true;
    }

    public static synchronized boolean archiveDriver(String id) {
        reload();
        Driver driver = findByIdInternal(id);
        if (driver == null) return false;
        driver.setArchived(true);
        save();
        return true;
    }

    public static synchronized Driver findById(String id) {
        reload();
        return findByIdInternal(id);
    }

    public static synchronized Driver findByName(String name) {
        reload();
        return findByNameInternal(name);
    }

    public static synchronized List<Driver> getActiveDrivers() {
        reload();
        List<Driver> result = new ArrayList<>();
        for (Driver d : drivers) {
            if (!d.isArchived()) result.add(d);
        }
        return Collections.unmodifiableList(result);
    }

    public static synchronized void startDeparture(Driver driver, String route,
                                                    String stop, String time) {
        if (driver == null) return;
        startDeparture(driver.getId(), route, stop, time);
    }

    public static synchronized void startDeparture(String driverId, String route,
                                                    String stop, String time) {
        reload();
        Driver driver = findByIdInternal(driverId);
        if (driver == null || driver.isArchived()) return;
        driver.startDeparture(route, stop, time);
        save();
    }

    public static synchronized void stopDeparture(Driver driver) {
        if (driver == null) return;
        stopDeparture(driver.getId());
    }

    public static synchronized void stopDeparture(String driverId) {
        reload();
        Driver driver = findByIdInternal(driverId);
        if (driver != null) {
            driver.stopDeparture();
            save();
        }
    }

    public static synchronized boolean addEarning(String id, double amount) {
        reload();
        Driver d = findByIdInternal(id);
        if (d == null || d.isArchived() || amount <= 0) return false;
        d.addEarnings(amount);
        save();
        return true;
    }

    public static synchronized boolean deductEarning(String id, double amount) {
        reload();
        Driver d = findByIdInternal(id);
        if (d == null || d.isArchived() || amount <= 0) return false;
        boolean success = d.deductEarnings(amount);
        if (success) save();
        return success;
    }

    /** Update the driver's live route stop and persist it immediately. */
    public static synchronized boolean updateStop(String driverId, String route, String stop) {
        reload();
        Driver d = findByIdInternal(driverId);
        if (d == null || d.isArchived() || !d.isDeparting()) return false;
        if (!route.equalsIgnoreCase(d.getRoute())) return false;
        d.setCurrentStop(stop);
        save();
        return true;
    }

    private static Driver findByIdInternal(String id) {
        if (id == null) return null;
        for (Driver d : drivers) {
            if (d.getId().equalsIgnoreCase(id.trim())) return d;
        }
        return null;
    }

    private static Driver findByNameInternal(String name) {
        if (name == null) return null;
        for (Driver d : drivers) {
            if (!d.isArchived() && d.getName().equalsIgnoreCase(name.trim())) return d;
        }
        return null;
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
