package model;

import javax.swing.JPasswordField;

public class Admin {
    public static final String USERNAME = "admin123";
    public static final String Password = "ADMINadmin123123";

    JPasswordField passwordText = new JPasswordField();
    char[] pass = passwordText.getPassword();
    String password = new String (pass);

          
    private final String name;

    public Admin() {
        this.name = USERNAME;
    }

    public String getName() {
        return name;
    }
}
