package gui;

import model.Driver;
import service.PassengerService;
import service.RouteService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Passenger dashboard.
 *
 * The dashboard reads the same local state used by DriverUser.  It refreshes
 * once per second, so a driver's route-stop change is reflected automatically
 * without XAMPP, MySQL, or another server.
 */
public class PassengerUser extends JFrame {
    private final PassengerService passengerService = new PassengerService();
    private final JComboBox<String> itmRoutes = new JComboBox<>(new String[]{"R1", "R2"});
    private final JComboBox<String> itmPassengerStop = new JComboBox<>();
    private final JTable tblAvailableDriver = new JTable();
    private final JLabel lblLive = new JLabel("● LIVE - Updates automatically from Driver dashboard");
    private final JLabel lblInfo = new JLabel("Select a route and your stop to see which jeepneys are approaching or have passed.");
    private Timer refreshTimer;
    private String passengerName = "Passenger";

    public PassengerUser() {
        this("Passenger");
    }

    public PassengerUser(String name) {
        passengerName = (name == null || name.trim().isEmpty()) ? "Passenger" : name.trim();
        initComponents();
        setTitle("TranSeat - Passenger Dashboard");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(900, 520));
        updateStopChoices();
        refreshAvailableDrivers();
        refreshTimer = new Timer(1000, e -> refreshAvailableDrivers());
        refreshTimer.start();
    }

    private void initComponents() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        root.setBackground(new Color(255, 153, 0));

        JPanel header = new JPanel(new BorderLayout(10, 10));
        header.setBackground(new Color(204, 204, 0));
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(160, 130, 0)),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)));

        JLabel title = new JLabel("TranSeat Passenger Dashboard");
        title.setFont(new Font("Verdana", Font.BOLD, 20));
        JLabel welcome = new JLabel("Welcome, " + passengerName + "!");
        welcome.setFont(new Font("Verdana", Font.BOLD, 14));
        lblLive.setFont(new Font("Segoe UI", Font.BOLD, 12));

        JPanel titleBox = new JPanel();
        titleBox.setOpaque(false);
        titleBox.setLayout(new BoxLayout(titleBox, BoxLayout.Y_AXIS));
        titleBox.add(title);
        titleBox.add(Box.createVerticalStrut(5));
        titleBox.add(welcome);
        titleBox.add(Box.createVerticalStrut(5));
        titleBox.add(lblLive);
        header.add(titleBox, BorderLayout.WEST);

        JButton btnLogOut = new JButton("Log Out");
        btnLogOut.addActionListener(e -> logout());
        header.add(btnLogOut, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        JPanel controls = new JPanel(new GridBagLayout());
        controls.setBackground(new Color(255, 204, 153));
        controls.setBorder(BorderFactory.createTitledBorder("Passenger Route Monitor"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.anchor = GridBagConstraints.WEST;

        g.gridx = 0; g.gridy = 0;
        controls.add(new JLabel("Route:"), g);
        g.gridx = 1;
        controls.add(itmRoutes, g);
        g.gridx = 2;
        controls.add(new JLabel("Your Stop:"), g);
        g.gridx = 3; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
        controls.add(itmPassengerStop, g);

        g.gridx = 0; g.gridy = 1; g.gridwidth = 4; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
        lblInfo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        controls.add(lblInfo, g);

        DefaultTableModel tableModel = new DefaultTableModel(
                new Object[][]{},
                new String[]{"Driver ID", "Plate No.", "Current Stop", "Next Stop", "Departure", "Status at Your Stop"}) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tblAvailableDriver.setModel(tableModel);
        tblAvailableDriver.setRowHeight(28);
        tblAvailableDriver.getTableHeader().setReorderingAllowed(false);
        tblAvailableDriver.setAutoCreateRowSorter(true);

        JScrollPane scroll = new JScrollPane(tblAvailableDriver);
        scroll.setBorder(BorderFactory.createTitledBorder("Available Jeepneys - Live Route Status"));

        // Make the table the main visible area instead of allowing the compact
        // control panel to consume most of the frame.
        JPanel mainArea = new JPanel(new BorderLayout(10, 10));
        mainArea.setOpaque(false);
        mainArea.add(controls, BorderLayout.NORTH);
        mainArea.add(scroll, BorderLayout.CENTER);
        root.add(mainArea, BorderLayout.CENTER);

        itmRoutes.addActionListener(e -> {
            updateStopChoices();
            refreshAvailableDrivers();
        });
        itmPassengerStop.addActionListener(e -> refreshAvailableDrivers());

        setContentPane(root);
        pack();
        setSize(900, 560);
    }

    private void updateStopChoices() {
        String route = String.valueOf(itmRoutes.getSelectedItem());
        String old = String.valueOf(itmPassengerStop.getSelectedItem());
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        List<String> stops = RouteService.getStops(route);
        for (String stop : stops) model.addElement(stop);
        itmPassengerStop.setModel(model);
        if (old != null && stops.contains(old)) itmPassengerStop.setSelectedItem(old);
        if (itmPassengerStop.getSelectedItem() == null && model.getSize() > 0) {
            itmPassengerStop.setSelectedIndex(0);
        }
    }

    private void refreshAvailableDrivers() {
        String route = String.valueOf(itmRoutes.getSelectedItem());
        String passengerStop = String.valueOf(itmPassengerStop.getSelectedItem());
        DefaultTableModel model = (DefaultTableModel) tblAvailableDriver.getModel();
        model.setRowCount(0);

        List<Driver> drivers = passengerService.getAvailableDrivers(route);
        for (Driver driver : drivers) {
            model.addRow(new Object[]{
                driver.getId(),
                driver.getPlateNumber(),
                driver.getCurrentStop(),
                passengerService.getNextStop(route, driver.getCurrentStop()),
                driver.getDepartureTime(),
                getPassengerStatus(route, driver.getCurrentStop(), passengerStop)
            });
        }

        if (drivers.isEmpty()) {
            model.addRow(new Object[]{"-", "-", "No active jeepney", "-", "-", "Not Available"});
        }

        lblInfo.setText("Route " + route + " • Your stop: " + passengerStop
                + " • Live data refreshes every second");
    }

    private String getPassengerStatus(String route, String currentStop, String passengerStop) {
        int current = RouteService.getStopIndex(route, currentStop);
        int target = RouteService.getStopIndex(route, passengerStop);
        List<String> stops = RouteService.getStops(route);

        if (current < 0 || target < 0) return "Unknown";
        if (current == target) return "AT YOUR STOP";
        if (current < target) {
            return "APPROACHING";
        }
        if (current >= stops.size() - 1 && target == stops.size() - 1) return "DESTINATION";
        return "ALREADY PASSED";
    }

    private void logout() {
        if (refreshTimer != null) refreshTimer.stop();
        new UserLogin().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PassengerUser().setVisible(true));
    }
}
