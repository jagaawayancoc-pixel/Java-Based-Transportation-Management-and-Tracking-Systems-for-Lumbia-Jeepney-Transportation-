TranSeat Management System - Modified Desktop Version

IMPORTANT: This version does NOT use XAMPP, PHP, MySQL, or a web server.
It is a Java Swing desktop application with a dependency-free local data file.

Run:
1. Open the project in NetBeans.
2. Clean and Build.
3. Run main.Main.

Login:
- Admin: name = admin123, secret password = ADMINadmin123123
- Passenger: enter any non-empty name and select Passenger.
- Driver: the administrator must first add the driver. Enter the driver's added unique name and select Driver.

LIVE PASSENGER/DRIVER SHARING:
- Driver departure data is saved locally to the user's TranSeatManagementSystem data folder.
- Passenger dashboard reloads this shared state every second.
- When a driver turns Departure ON, the jeepney appears for passengers on the selected route.
- When the driver changes the current route stop, the Passenger dashboard updates automatically.
- When the driver turns Departure OFF or logs out, the jeepney is removed from the Passenger availability list.
- Because the shared state is stored on disk, separate Java application processes on the same computer can see the same driver/departure state.

Passenger dashboard:
- Select R1 or R2.
- Select the passenger's desired stop.
- See Driver ID, Plate No., Current Stop, Next Stop, Departure Time, and Status at Your Stop.
- Status can be APPROACHING, AT YOUR STOP, or ALREADY PASSED.
- The dashboard refreshes every second.

Routes:
R1 - Lumbia to Cogon
R2 - Lumbia to Carmen

R1 stops:
Centro Lumbia -> Palalan Road -> Masterson Ave. -> Kagay-an Bridge ->
Rodelsa Circle -> Tomas Saco St. -> Fernandez St. -> Corrales Ave. ->
Hayes St. -> Cogon Public Market

R2 stops:
Centro Lumbia -> F. Delima St. -> Masterson Ave. -> Macapagal Drive ->
SM Bypass Road -> C. Diel St. -> Villarin St. -> Max Suniel St. ->
V. Neri St. -> Carmen Public Market

Administrator:
- Add, update, search, and archive drivers.
- Add driver earnings and deduct earnings/penalties.
- View active departure status and round trips.

Driver:
- Set departure route/time.
- Turn departure ON/OFF.
- Select and change the current route stop.
- Route-stop changes are immediately persisted and become visible to passengers on their next refresh.

Data storage:
- No XAMPP or MySQL is required.
- Driver records, active departures, round trips, and earnings are stored locally in a serialized data file.
- The data file is stored under the current user's home directory in:
  TranSeatManagementSystem/drivers.dat

Notes:
- The project still contains the original NetBeans .form files for the GUI screens.
- PassengerUser.java was redesigned in code to provide the live route-monitor dashboard.
- RouteService.java centralizes the R1/R2 stop definitions so Driver and Passenger screens use the same stop data.
- LocalDataStore.java provides dependency-free persistence and cross-process synchronization through atomic file replacement.
